import 'package:awesome_notifications/awesome_notifications.dart';

List<NotificationChannelGroup> channelGroups() {
  return [
    //
    //---
    NotificationChannelGroup(
      channelGroupKey: 'general_channel_group',
      channelGroupName: 'General',
    )
    //---
    //
  ];
}
