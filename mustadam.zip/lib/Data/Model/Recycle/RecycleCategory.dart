enum RecycleCategory {
  plastic,
  paper,
  glass,
  metal,
  other,
}
