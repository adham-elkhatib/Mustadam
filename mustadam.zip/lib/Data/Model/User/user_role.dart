enum UserRole { student, staff }
