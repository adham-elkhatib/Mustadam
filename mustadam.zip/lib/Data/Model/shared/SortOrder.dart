enum SortOrder { newestFirst, oldestFirst }
