package com.example.mustadam

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
